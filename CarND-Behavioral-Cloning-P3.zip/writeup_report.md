# **Behavioral Cloning** 

## Writeup Template

### You can use this file as a template for your writeup if you want to submit it as a markdown file, but feel free to use some other method and submit a pdf if you prefer.

---

**Behavioral Cloning Project**

The goals / steps of this project are the following:
* Use the simulator to collect data of good driving behavior
* Build, a convolution neural network in Keras that predicts steering angles from images
* Train and validate the model with a training and validation set
* Test that the model successfully drives around track one without leaving the road
* Summarize the results with a written report


## Rubric Points
### Here I will consider the [rubric points](https://review.udacity.com/#!/rubrics/432/view) individually and describe how I addressed each point in my implementation.  

---
### Files Submitted & Code Quality

#### 1. Submission includes all required files and can be used to run the simulator in autonomous mode

My project includes the following files:
* model.py containing the script to create and train the model      -> YES
* drive.py for driving the car in autonomous mode                   -> YES, without any changes
* model.h5 containing a trained convolution neural network          -> YES, based on the NVIDIA NN
* writeup_report.md or writeup_report.pdf summarizing the results   -> YES, this document

#### 2. Submission includes functional code
Using the Udacity provided simulator and my drive.py file, the car can be driven autonomously around the track by executing 
```sh
python drive.py model.h5
```
- Yes it can.

#### 3. Submission code is usable and readable

The model.py file contains the code for training and saving the convolution neural network. The file shows the pipeline I used for training and validating the model, and it contains comments to explain how the code works.
- Yes it does.

### Model Architecture and Training Strategy

#### 1. An appropriate model architecture has been employed

My code contains 2 models with which I experimented. One is the LeNet, and one is the NVIDIA architecture. Ultimately, I went with the NVIDIA model as I got better results in the simulator. The model first normalizes the data to values between -0.5 and 0.5. Afterwards it will crop the images to eliminate the environments like clouds/trees from the top and the front of the car from the bottom. After that there are 5 CNNs with a Relu for nonlinearity. For the first 3, 5x5 filters were used, for the last 2 3x3. The depths are as follows: 24, 36, 48, 64 and 64. After that the model is flattened and 4 FC layers are implemented: 100, 50, 10 and 1. The complete model is build up using Keras.

#### 2. Attempts to reduce overfitting in the model

The model does not contain dropout layers as the training result did not really show big overfitting, but the data was split into 'training' and 'validation' using the Keras 'fit' function. The general rule of thumb is used by having 20% of the complete dataset been used for validation of the trained model. Ultimately, the model was tested by running it through the simulator and ensuring that the vehicle could stay on the track which it did.

#### 3. Model parameter tuning

The model used an adam optimizer, so the learning rate was not tuned manually. We used 3 EPOCHS to train the training dataset.

#### 4. Appropriate training data

As I was not able to drive in a proper way in the simulator using my laptop, I executed this project with the dataset provided by Udacity. I am aware that the smoothness of the car staying in the middle of the road and starting to turn when a corner arrives can be improved to add more data to my dataset. I would collect data from the following driving manoeuvres to improve my model:
- Drive from the side of the road to the middle. This at different parts of the track.
- Collect more driving data around parts of the track which are different compared to the biggest chunk of the track. For example, where there is a sand road exit, or where there is a transition from shade to sun on the road, etc.
- Around the bridge as the texture/color of the bridge compared to the rest of the track is completely different.
- I would drive the track backwards to make the model generalize better. However, this was virtually covered by flipping the original dataset.

As X_train/y_train dataset preprocessing I undertook the following:
- convert the images from BGR to RGB as the simulator will fed the trained model with RGB images. 
- loaded images from 3 camera's to have a better result in corners and pulling the car back to the middle of the road. For the left and right image, a correction factor was included to the steering angle to improve the change in direction when going off the middle of the road.
- for the complete dataset, images were then flipped and added to the dataset. This gave us more data to train on and data that now virtually was edited and doing a clockwize tour around the track instead of a anti-clockwize tour.
- during the training, using the Keras library, the crop function was used to cut off trees/sky at the top and the front of the car at the bottom. A positive side effect of this was that the number of pixels went down which speed up the training.

### Model Architecture and Training Strategy

#### Solution Summary

I used the Udacity provided dataset as I was not able to drive in the simulator in a smooth way to collect data. After the preprocessing and augmentation the total dataset had 48216 images from which 38573 (80%) were used for training the model and 9643 (20%) for validating the trained model. Before starting the training, the dataset was randomly shuffled. After training and validating the trained model, I ran the car in the simulator to see how well the model would drive autonomous around the track. First the car would go off-track immediately and drive into the water. The biggest improvement came after figuring out the BGR to RGB conversion need. After that it was finetuning the correction factor of the left and right camera images to increase the car driving well in the middle of the road and rescuing itself when driving at the sides of the road going back to the middle. As explained above, to improve the smoothness even more, more data has to be collected in specific driving scenario's. However, to finish the project, the car is able to drive multiple laps on the track without going off-track. In the submission, the video shows the car driving 1.5 laps in autonomous mode.
